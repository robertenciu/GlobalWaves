package media.music;

public enum MusicCollectionType {
    PLAYLIST,
    ALBUM
}
