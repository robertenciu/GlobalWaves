package page;

public enum PageLocator {
    HOME,
    LIKED_CONTENT,
    ARTIST,
    HOST
}
